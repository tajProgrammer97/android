package dev.tajik.myweb

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : AppCompatActivity() {
    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val myWebView: WebView = findViewById(R.id.myWebView)
        myWebView.settings.javaScriptEnabled = true // enable JavaScript
        myWebView.webViewClient = WebViewClient() // handling page navigation
        myWebView.loadUrl("https://komil.pro/p/zgame/") // load web page
        //myWebView.loadUrl("https://yandex.ru") // load web page
    }
}